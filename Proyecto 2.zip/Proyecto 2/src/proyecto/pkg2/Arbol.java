/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg2;

/**
 *
 * @author macbookpro
 */
public class Arbol {
    public Nodo raiz;
    public int tamaño;
    public Nodo anterior;
    
    
    public Arbol(Nodo primero){
        this.raiz = primero;
        this.anterior = null;
        this.tamaño = 1;
        
    }

    Arbol() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
public void Insertar(Arbol arbol, String pregunta, String aniNuevo , boolean direccion){
    //se presentara la nueva pregunta en base al animal que ya existe
    //dependiendo de la respuesta se pondra a la izquiersa(SI) o a la derecha(NO)
    
    String aniViejo = arbol.raiz.getInfo();
    arbol.raiz.setInfo(pregunta);
    Nodo animalViejo = new Nodo(aniViejo);
    Nodo animalNuevo = new Nodo(aniNuevo);
    
    if(direccion == true){
        arbol.raiz.setHijoIzquierdo(animalViejo);
        arbol.raiz.setHijoDerecho(animalNuevo);
 
    }else{
        arbol.raiz.setHijoIzquierdo(animalNuevo);
        arbol.raiz.setHijoDerecho(animalViejo);
         
    }
    
}

public void Mover(Arbol arbol, boolean respuesta){
    
    if(respuesta == true){
        
        arbol.raiz = raiz.hijoIzquierdo;
       
    }else if(respuesta == false){
        
        arbol.raiz = raiz.hijoDerecho;
        
    }
    
}


}
